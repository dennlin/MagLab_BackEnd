import express from 'express'
import TestController from './test-controller.js';

const router = express.Router() // get access to express router

const controller = new TestController();

// router to handle POST /api/echo
router.route('/echo')
   .post(controller.echo);


export default router